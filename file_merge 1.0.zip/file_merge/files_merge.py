import pandas as pd
import sys
import glob

path = sys.path[0] + "/input"

file_list = glob.glob(path + "/*.tsv")

excl_list = []

for file in file_list:
	excl_list.append(pd.read_csv(file, delimiter='\t', usecols=['hash']))
    

excl_merged = pd.DataFrame()

i = 1
for excl_file in excl_list:
	
	excl_merged = excl_merged.append(
	excl_file, ignore_index=True)
	print(i)
	i += 1


excl_merged.to_csv(fr'{sys.path[0]}\output\a.txt', header= False, index=False)